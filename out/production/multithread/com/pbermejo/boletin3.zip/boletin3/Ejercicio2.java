package com.pbermejo.boletin3;

import java.util.ArrayList;

public class Ejercicio2 {
    private static int INICIO = 5;
    private static int FIN = 14;
    private static ArrayList<Thread> hilos = new ArrayList<>();

    private static void crearHilos(){
        for (int i = INICIO; i <= FIN; i++) {
            hilos.add(new Thread(new FactorialRunnableModificado(i)));
        }
    }

    private static void lanzarHilos(){
        for (Thread hilo : hilos){
            hilo.start();
        }
    }

    public static void main(String[] args) {
        crearHilos();
        lanzarHilos();
        System.out.println("FIN main");
    }
}
