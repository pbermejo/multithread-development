package com.pbermejo.boletin6;

public class Ejercicio1Contador {
    private int contador = 0;

    public int getContador() {
        return contador;
    }

    public void incrementar(){
        this.contador++;
    }
}
