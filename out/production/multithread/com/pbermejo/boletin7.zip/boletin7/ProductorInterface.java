package com.pbermejo.boletin7;

public interface ProductorInterface {
    void ponerEnCompartido(int n);
    void mostrarCompartido();
}
