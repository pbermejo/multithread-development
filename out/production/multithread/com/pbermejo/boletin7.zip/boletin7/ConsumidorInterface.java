package com.pbermejo.boletin7;

public interface ConsumidorInterface {
    int quitarDeCompartido();
    void mostrarCompartido();
}
